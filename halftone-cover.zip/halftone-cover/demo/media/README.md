Stand-in clips so the demo runs out of the box. They are synthetic — a lit
silhouette on a plain wall, which is the lighting the effect is tuned for.

Replace with your own footage, or point `sources` at files elsewhere.
